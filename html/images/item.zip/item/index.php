<?php 
header("Location: " . __HOST__);
?>